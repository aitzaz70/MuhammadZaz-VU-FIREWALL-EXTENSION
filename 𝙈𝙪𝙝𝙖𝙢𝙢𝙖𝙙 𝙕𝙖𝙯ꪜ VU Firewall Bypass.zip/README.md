# firewall-bypass-extension
Enable copy paste on quiz and gdb pages, mark lesson videos as viewed, and bypass VU quiz firewall.
